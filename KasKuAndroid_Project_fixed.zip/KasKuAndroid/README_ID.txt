PROYEK ANDROID KASUKU — VERSI SEDERHANA

Isi:
- Aplikasi HTML KasKu di app/src/main/assets/index.html
- Pembungkus Android WebView agar berjalan sebagai aplikasi Android.
- Pemasukan, pengeluaran, riwayat, dan saldo otomatis sesuai aplikasi HTML.
- Penyimpanan browser lokal (localStorage) pada perangkat.

CARA MEMBUAT APK DENGAN ANDROID STUDIO
1. Instal Android Studio di komputer/laptop.
2. Ekstrak folder KasKuAndroid dari ZIP ini.
3. Buka Android Studio > Open, lalu pilih folder KasKuAndroid.
4. Tunggu Gradle Sync selesai. Jika diminta, instal Android SDK Platform 35.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah berhasil, klik "locate" pada notifikasi build. APK biasanya ada di:
   app/build/outputs/apk/debug/app-debug.apk
7. Pindahkan APK ke HP Android dan buka untuk memasang. Jika diminta, izinkan
   instalasi aplikasi dari sumber tersebut.

CATATAN
- Proyek ini adalah sumber proyek Android, bukan file APK yang sudah dikompilasi.
- Kompilasi membutuhkan Android Studio/Android SDK dan koneksi internet pertama kali.
- Data tersimpan lokal di aplikasi/perangkat. Jangan menghapus data aplikasi atau
  menghapus instalasi jika ingin mempertahankan data. Ekspor/cadangkan catatan secara berkala.
- Versi ini tidak memiliki sinkronisasi cloud antarperangkat.
